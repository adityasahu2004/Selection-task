from django.urls import path, include
from django.shortcuts import render
from rest_framework.routers import DefaultRouter
from library.views import home, book_detail, library_details 
from library.views import BookViewSet, MemberViewSet, LoanViewSet

router = DefaultRouter()
router.register(r'books', BookViewSet, basename='books')
router.register(r'members', MemberViewSet, basename='members')
router.register(r'loans', LoanViewSet, basename='loans')

urlpatterns = [

    path('', home, name='home'), 

    path('book/<int:book_id>/', book_detail, name='book_detail'), 

 
    path('api/', include(router.urls)),

    path('legacy-home/', lambda request: render(request, 'home.html'), name='legacy_home'),  
  
    path('details/', library_details, name='library_details'),  
    path('library/details/', library_details, name='library_details'),
]
