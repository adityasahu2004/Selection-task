from rest_framework import serializers
from .models import Book, Member, Loan
from django.contrib.auth.models import User

class BookSerializer(serializers.ModelSerializer):
    class Meta:
        model = Book
        fields = '__all__' 
class MemberSerializer(serializers.ModelSerializer):

    user = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = Member
        fields = '__all__' 


class LoanSerializer(serializers.ModelSerializer):
    
    book = BookSerializer(read_only=True) 
    member = MemberSerializer(read_only=True)

    class Meta:
        model = Loan
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
   
    member = serializers.PrimaryKeyRelatedField(queryset=Member.objects.all(), source='member_set', many=False)

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'member'] 
