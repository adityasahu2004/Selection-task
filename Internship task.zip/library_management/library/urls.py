from django.urls import path, include
from . import views
from rest_framework.routers import DefaultRouter
from .views import BookViewSet, MemberViewSet, LoanViewSet

# Create a DefaultRouter and register the viewsets
router = DefaultRouter()
router.register(r'books', BookViewSet, basename='books')
router.register(r'members', MemberViewSet, basename='members')
router.register(r'loans', LoanViewSet, basename='loans')

urlpatterns = [
    path('', views.home, name='home'),  # Home page for the library

    path('book/<int:book_id>/', views.book_detail, name='book_detail'),  # Dynamic URL for book details

    path('details/', views.details_view, name='details'), 
    path('api/', include(router.urls)), 
    path('api/books/', views.book_list, name='book_list'),  

    path('api/members/', views.MemberViewSet.as_view({'get': 'list'}), name='member_list'),
    path('api/loans/', views.LoanViewSet.as_view({'get': 'list'}), name='loan_list'),
]
