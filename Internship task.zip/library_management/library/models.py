from django.db import models
from django.contrib.auth.models import User
from datetime import timedelta

class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    genre = models.CharField(max_length=50)  
    total_copies = models.PositiveIntegerField()  
    available_copies = models.PositiveIntegerField()  

    def __str__(self):
        return self.title

class Member(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=15)
    address = models.TextField()

    def __str__(self):
        return self.user.username 

class Loan(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE) 
    member = models.ForeignKey(Member, on_delete=models.CASCADE) 
    borrowed_date = models.DateField(auto_now_add=True)  
    due_date = models.DateField()
    returned_date = models.DateField(null=True, blank=True) 
    fine = models.DecimalField(max_digits=6, decimal_places=2, default=0.0) 

    def calculate_fine(self):
        if self.returned_date and self.returned_date > self.due_date:
            overdue_days = (self.returned_date - self.due_date).days 
            self.fine = overdue_days * 5 
            self.save()

    def __str__(self):
        return f"{self.book.title} borrowed by {self.member.user.username}" 
