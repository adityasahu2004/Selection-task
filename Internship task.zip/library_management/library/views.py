from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Book, Member, Loan
from .serializers import BookSerializer, MemberSerializer, LoanSerializer
from django.utils.timezone import now
from datetime import timedelta


def home(request):
    books = Book.objects.all()  
    return render(request, 'home.html', {'books': books})  

def book_detail(request, book_id):
    book = get_object_or_404(Book, id=book_id)  
    return render(request, 'book_detail.html', {'book': book}) 

def details_view(request):
    books = Book.objects.all()
    members = Member.objects.all()
    loans = Loan.objects.all()

    return render(request, 'details.html', {
        'books': books,
        'members': members,
        'loans': loans
    })

def library_details(request):
    books = Book.objects.all()
    members = Member.objects.all()
    loans = Loan.objects.all()

    return render(request, 'library/library_details.html', {
        'books': books,
        'members': members,
        'loans': loans
    })

def book_list(request):
    search_term = request.GET.get('search', '') 
    books = Book.objects.filter(
        title__icontains=search_term) | Book.objects.filter(
        author__icontains=search_term) | Book.objects.filter(
        genre__icontains=search_term)

    books_data = list(books.values()) 
    return JsonResponse({'books': books_data}) 


class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

    def get_permissions(self):
        if self.action in ['create', 'update', 'destroy']:
            return [IsAuthenticated()] 
        return []


class MemberViewSet(viewsets.ModelViewSet):
    queryset = Member.objects.all()
    serializer_class = MemberSerializer
    permission_classes = [IsAuthenticated]  

# Loan ViewSet
class LoanViewSet(viewsets.ModelViewSet):
    queryset = Loan.objects.all()
    serializer_class = LoanSerializer
    permission_classes = [IsAuthenticated] 

    @action(detail=False, methods=['post'])
    def borrow(self, request):
        book_id = request.data.get('book_id')
        member_id = request.data.get('member_id')
        try:
            book = Book.objects.get(id=book_id)
            member = Member.objects.get(id=member_id)
            if book.available_copies > 0:
                loan = Loan.objects.create(
                    book=book,
                    member=member,
                    due_date=now().date() + timedelta(days=14)
                )
                book.available_copies -= 1
                book.save()
                return Response({'message': 'Book borrowed successfully!', 'loan_id': loan.id}, status=status.HTTP_201_CREATED)
            return Response({'error': 'No available copies!'}, status=status.HTTP_400_BAD_REQUEST)
        except Book.DoesNotExist:
            return Response({'error': 'Book not found!'}, status=status.HTTP_404_NOT_FOUND)
        except Member.DoesNotExist:
            return Response({'error': 'Member not found!'}, status=status.HTTP_404_NOT_FOUND)


    @action(detail=False, methods=['post'])
    def return_book(self, request):
        loan_id = request.data.get('loan_id')
        try:
            loan = Loan.objects.get(id=loan_id)
            loan.returned_date = now().date()
            loan.calculate_fine() 
            loan.book.available_copies += 1
            loan.book.save()
            loan.save()
            return Response({'message': 'Book returned successfully!', 'fine': loan.fine}, status=status.HTTP_200_OK)
        except Loan.DoesNotExist:
            return Response({'error': 'Loan not found!'}, status=status.HTTP_404_NOT_FOUND)
